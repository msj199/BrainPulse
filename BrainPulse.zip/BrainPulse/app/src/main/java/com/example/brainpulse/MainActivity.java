package com.example.brainpulse;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.FileAsyncHttpResponseHandler;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Objects;

import cz.msebera.android.httpclient.Header;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView totalQuestionsTextView;
    TextView questionTextView, p1Text,p2Text;
    Button ansA, ansB, ansC, ansD;
//    Button submitBtn;

    int p1score = 0;
    int p2score = 0;
    int totalQuestion ;
    int currentQuestionIndex = 0;
    String selectedAnswer = "";

    AsyncHttpClient client;
    Workbook workbook;
    List<String> qs,ca,category,points;
    List<List<String>> cs;
    boolean mp = true;
    String turn = "p1";
    RelativeLayout r;
    int start=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        totalQuestionsTextView = findViewById(R.id.Total);
        questionTextView = findViewById(R.id.Question);
        ansA = findViewById(R.id.button1);
        ansB = findViewById(R.id.button2);
        ansC = findViewById(R.id.button3);
        ansD = findViewById(R.id.button4);
//        submitBtn = findViewById(R.id.submit);
        p1Text = findViewById(R.id.Player_1_Score);
        p2Text = findViewById(R.id.Player_2_Score);
        r = findViewById(R.id.relative);

        String url = "https://github.com/msj199/BrainPulse/raw/main/Database.xls";
        qs = new ArrayList<>();
        cs = new ArrayList<>();
        ca = new ArrayList<>();
        category = new ArrayList<>();
        points = new ArrayList<>();
        client = new AsyncHttpClient();
//        r.setBackgroundResource(R.drawable.test);


        client.get(url, new FileAsyncHttpResponseHandler(this) {
            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, File file) {
                Toast.makeText(MainActivity.this,"Download Failed",Toast.LENGTH_SHORT).show();
                Log.d("Question","failed");
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, File file) {
                Log.d("Question","Success");

//                cs.add(new ArrayList<>());
//                Toast.makeText(MainActivity.this,"Downloaded",Toast.LENGTH_SHORT).show();
                WorkbookSettings ws = new WorkbookSettings();
                ws.setGCDisabled(true);
                if(file != null){
                    Log.d("Question","Not Null");
                    try {

                        Workbook w1= workbook.getWorkbook(file);
                        Sheet sheet = w1.getSheet(0);
                        Log.d("Question",Integer.toString(sheet.getRows()));
                        for(int i=0 ; i<sheet.getRows();i++){
                            Cell[] row = sheet.getRow(i);
                            qs.add(row[0].getContents());
                            Log.d("Question",qs.get(i));
                            cs.add(new ArrayList<>(Arrays.asList(row[1].getContents().split(","))));
                            Log.d("Question",cs.get(i).toString());
                            ca.add(row[2].getContents());
                            Log.d("Question",ca.get(i));
                            points.add(row[3].getContents());
                            Log.d("Question",points.get(i));
                            category.add(row[4].getContents());
                            Log.d("Question",category.get(i));


                        }
                    } catch (IOException e) {

                        Log.d("Question",e.toString());
                    } catch (BiffException e) {
                        Log.d("Question",e.toString());
                    }
                    totalQuestion = qs.size();

                }

            }
        });

        ansA.setOnClickListener(this);
        ansB.setOnClickListener(this);
        ansC.setOnClickListener(this);
        ansD.setOnClickListener(this);
//        submitBtn.setOnClickListener(this);



        totalQuestionsTextView.setText("Total questions : " + totalQuestion);

        loadNewQuestion();


    }

    @Override
    public void onClick(View view) {

        ansA.setBackgroundColor(Color.WHITE);
        ansB.setBackgroundColor(Color.WHITE);
        ansC.setBackgroundColor(Color.WHITE);
        ansD.setBackgroundColor(Color.WHITE);

        Button clickedButton = (Button) view;
        if ((clickedButton.getId() == R.id.button1) || (clickedButton.getId() == R.id.button2)|| (clickedButton.getId() == R.id.button3) || (clickedButton.getId() == R.id.button4) ) {
            if (selectedAnswer.equals(ca.get(currentQuestionIndex))) {
                if(mp & Objects.equals(turn, "p2")){
                    p2score = p2score + Integer.parseInt(points.get(currentQuestionIndex));
                    turn = "p1";
                }
                else {
                    p1score = p1score + Integer.parseInt(points.get(currentQuestionIndex));
                    turn = "p2";
                }

            }

            currentQuestionIndex++;
            loadNewQuestion();


        } else {
            //choices button clicked
            selectedAnswer = clickedButton.getText().toString();
//            clickedButton.setBackgroundColor(Color.MAGENTA);

        }
        p1Text.setText("Player 1 score " + p1score);
        p2Text.setText("Player 1 score " + p2score);


    }

    void loadNewQuestion() {

        if ((currentQuestionIndex == totalQuestion) ) {
            finishQuiz();
            return;
        }

        questionTextView.setText(qs.get(currentQuestionIndex));
        ansA.setText(cs.get(currentQuestionIndex).get(0));
        ansB.setText(cs.get(currentQuestionIndex).get(1));
        ansC.setText(cs.get(currentQuestionIndex).get(2));
        ansD.setText(cs.get(currentQuestionIndex).get(3));


    }

    void finishQuiz() {
        if (start == 0 || start == 1){
            Log.d("What","What");
            start++;
            restartQuiz();

        }
        else {
            String passStatus = "";
            if (p1score > 5 * 0.60) {
                passStatus = "Passed";
            } else {
                passStatus = "Failed";
            }

            new AlertDialog.Builder(this)
                    .setTitle(passStatus)
                    .setMessage("Score is " + p1score + " out of " + totalQuestion)
                    .setPositiveButton("Restart", (dialogInterface, i) -> restartQuiz())
                    .setCancelable(false)
                    .show();
        }

    }

    void restartQuiz() {
        p1score = 0;
        p2score = 0;
        currentQuestionIndex = 0;
        loadNewQuestion();
    }

}