package com.example.brainpulse;


public class Database {


    public static String question[] = {
            "______ is a disorder or bad functioning (malfunction of mind or body) which leads to departure of good health",
            "Disease of the heart, joints and nervous system are called_____",
            "Hemophilia disease can be transferred through ______________",
            "A bacterial disease is____"
    };

    public static String choices[][] = {
            {"Physical disease", "Health", "Disease", "Infectious disease"},
            {"Degenerative diseases", "Communicable diseases", "Deficiency diseases", "Mental diseases"},
            {"Heredity", "Vector", "Vehicle", "Pollutant"},
            {"Tuberculosis", "Polio", "Influenza", "All of the above"}
    };

    public static String correctAnswers[] = {
            "Disease",
            "Degenerative diseases",
            "Heredity",
            "Tuberculosis"
    };
}